# kali_parrot_terminal

Parrot OS Terminal For Kali linux

# How To?

Copy paste the .bashrc file in your root directory make sure first to backup the existing one if it's there.!
Or else Just run the shell script "install.sh"

Following are the commands if you're n00b:-

```sh
git clone https://github.com/m4xx101/kali_parrot_terminal.git

cd kali_parrot_terminal/

chmod +x install.sh

./install.sh
```
